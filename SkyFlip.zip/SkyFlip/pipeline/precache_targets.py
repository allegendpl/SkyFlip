#!/usr/bin/env python3
"""Pre-cache cutouts + manifests for the five official test targets into frontend/public/demo-data/."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from astropy.visualization import ZScaleInterval

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))

from app.adapters import catalogs  # noqa: E402
from app.adapters.spherex import SpherexAdapter  # noqa: E402
from app.imaging import stretch  # noqa: E402
from PIL import Image  # noqa: E402

OUT = ROOT / "frontend" / "public" / "demo-data"
FOV = 0.05
BAND = "SPHEREx-D1"
MAX_FRAMES = 6

TARGETS = [
    {"id": "wise0855", "name": "WISE 0855", "ra": 133.79512917, "dec": -7.24514722},
    {"id": "barnards_star", "name": "Barnard's Star"},
    {"id": "epsilon_indi_b", "name": "Epsilon Indi B"},
    {"id": "rw_aurigae", "name": "RW Aurigae"},
    {"id": "r_draconis", "name": "R Draconis"},
]


def resolve(t):
    if "ra" in t:
        return t["ra"], t["dec"]
    r = catalogs.resolve_name(t["name"])
    return r["ra"], r["dec"]


def save_png(arr, path: Path):
    scaled = stretch(arr, "asinh")
    img = Image.fromarray((scaled * 255).astype(np.uint8), mode="L")
    img.save(path)


def main() -> int:
    adapter = SpherexAdapter(cache_dir=ROOT / "backend" / ".cache")
    OUT.mkdir(parents=True, exist_ok=True)
    summary = []
    for t in TARGETS:
        print("===", t["name"])
        try:
            ra, dec = resolve(t)
        except Exception as exc:
            print("  resolve failed:", exc)
            continue
        dest = OUT / t["id"]
        dest.mkdir(parents=True, exist_ok=True)
        try:
            obs = adapter.find_observations(ra, dec, fov_deg=FOV, bandpasses=(BAND,))
        except Exception as exc:
            print("  discovery failed:", exc)
            continue
        # unique days
        by_day = {}
        for o in sorted(obs, key=lambda x: x.mjd):
            by_day.setdefault(int(o.mjd), o)
        chosen = list(by_day.values())
        if len(chosen) > MAX_FRAMES:
            idxs = np.linspace(0, len(chosen) - 1, MAX_FRAMES).astype(int)
            chosen = [chosen[i] for i in idxs]
        frames = []
        for i, o in enumerate(chosen):
            try:
                cut = adapter.fetch_cutout(o)
                cut = adapter.parse_cutout_fits(cut.fits_path, o, target_ra=ra, target_dec=dec)
            except Exception as exc:
                print("  cutout fail", o.obs_id, exc)
                continue
            png_name = f"frame_{i:02d}_{o.mjd:.5f}.png"
            save_png(cut.image, dest / png_name)
            frames.append(
                {
                    "epoch_id": f"{o.obs_id}|{o.bandpass}|{o.mjd}",
                    "obs_id": o.obs_id,
                    "mjd": o.mjd,
                    "time_iso": o.time_iso,
                    "bandpass": o.bandpass,
                    "detector": o.detector,
                    "collection": o.collection,
                    "png": png_name,
                    "central_wavelength_um": cut.central_wavelength_um,
                    "flag_summary": cut.flag_summary,
                    "image_shape": list(cut.image.shape),
                }
            )
            print("  wrote", png_name)
        man = {
            "target_id": t["id"],
            "name": t["name"],
            "ra": ra,
            "dec": dec,
            "fov_deg": FOV,
            "bandpass": BAND,
            "pixel_scale_arcsec": 6.15,
            "frames": frames,
            "source": "cached-demo",
            "is_synthetic": False,
            "credit": "NASA/JPL-Caltech/IPAC — SPHEREx at IRSA",
        }
        (dest / "manifest.json").write_text(json.dumps(man, indent=2, default=str))
        summary.append({"id": t["id"], "n_frames": len(frames), "ra": ra, "dec": dec})
    (OUT / "index.json").write_text(json.dumps({"targets": summary}, indent=2))
    print("Done", summary)
    return 0 if summary else 1


if __name__ == "__main__":
    raise SystemExit(main())
