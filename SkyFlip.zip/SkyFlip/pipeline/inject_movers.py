#!/usr/bin/env python3
"""Inject synthetic movers into cutout arrays for recovery tests. Always is_synthetic=True."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "frontend" / "public" / "demo-data" / "synthetic_movers.json"


def gaussian_blob(shape, x, y, amp=5.0, fwhm=2.0):
    yy, xx = np.indices(shape)
    s = fwhm / 2.355
    return amp * np.exp(-((xx - x) ** 2 + (yy - y) ** 2) / (2 * s * s))


def main() -> int:
    shape = (29, 29)
    frames = []
    x0, y0 = 14.0, 14.0
    for i, mjd in enumerate([60800.0, 60980.0, 61160.0]):
        img = np.random.normal(0, 0.3, size=shape)
        x = x0 + i * 1.5
        y = y0 + i * 0.4
        img += gaussian_blob(shape, x, y, amp=8.0)
        frames.append(
            {
                "mjd": mjd,
                "x": x,
                "y": y,
                "is_synthetic": True,
                "note": "Simulated mover on noise background for recovery tests only",
            }
        )
    OUT.write_text(
        json.dumps(
            {
                "is_synthetic": True,
                "badge": "SIMULATED / TEST DATA",
                "frames": frames,
                "truth_pm_pix_per_epoch": {"dx": 1.5, "dy": 0.4},
            },
            indent=2,
        )
    )
    print("Wrote", OUT)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
