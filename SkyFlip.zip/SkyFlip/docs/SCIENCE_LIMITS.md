# Science limits and citations

## Pixel scale

- SPHEREx Spectral Image native scale: **6.15 arcsec/pixel** (Explanatory Supplement; live SIA `s_pixel_scale`).
- Older instrument page value 6.2″ is ~consistent; SkyFlip uses 6.15″.

## Level-2 IMAGE

- Units: MJy/sr.
- Zodiacal light is **not** subtracted from IMAGE (see ZODI extension).

## LVF / wavelength

- Wavelength varies across each detector. Blinking mismatched wavelengths can mimic variability.
- Prefer same detector / nearby λ when comparing epochs.

## Absorption band markers (spectrum panel)

Approximate published IR band regions used **for annotation only** (not object classification):

| Feature | Approx. µm | Notes |
| --- | --- | --- |
| H₂O | 2.7–3.5 | Broad ice/gas features in near-IR |
| CO₂ | 4.1–4.4 | Common CO₂ ice/gas region |
| CO | 4.5–4.8 | CO fundamental region |

These are standard laboratory/astronomical IR band locations for educational overlays. SkyFlip does **not** infer chemistry or object type from a cutout spectrum.

## Planet X meter

- Parallax semi-amplitude ≈ 206265″ / d(AU).
- Six-month max shift up to ~2× that (geometry-dependent).
- Reflected light ∝ R² A / d⁴ — illustrative.
- SPHEREx point-source depth: cite Explanatory Supplement / mission docs before quoting a magnitude limit (`TODO(VERIFY)` exact QR depth number for UI comparison).

## Proper motion for WISE 0855 ghost track

If SIMBAD PM is unavailable, the API may use an approximate literature-scale ~8″/yr motion with an explicit uncertainty note. Prefer Gaia/AllWISE when available.
