import { useEffect, useState } from "react";
import { api } from "../lib/api";

export function ScoreboardPanel() {
  const [data, setData] = useState<{ results: Record<string, unknown>; explanation: string; source: string } | null>(
    null
  );
  const [err, setErr] = useState("");

  useEffect(() => {
    api
      .scoreboard()
      .then(setData)
      .catch((e) => setErr(String(e)));
  }, []);

  const field = (data?.results?.field_validation ?? {}) as Record<string, unknown>;
  const selfTest = (data?.results?.motion_fit_self_test ?? {}) as Record<string, unknown>;

  return (
    <section className="panel" aria-label="Validation scoreboard">
      <h2>Validation scoreboard</h2>
      {err && <p className="error">{err}</p>}
      {!data ? (
        <p>Loading…</p>
      ) : (
        <>
          <p>{data.explanation}</p>
          <p className="hint">Data source: {data.source}</p>
          <div className="score-grid">
            <div>
              <div className="num">{String(field.n_recovered ?? "—")}</div>
              <div>recovered</div>
            </div>
            <div>
              <div className="num">{String(field.n_missed ?? "—")}</div>
              <div>missed</div>
            </div>
            <div>
              <div className="num">{String(field.n_false_candidates ?? "—")}</div>
              <div>false candidates</div>
            </div>
            <div>
              <div className="num">
                {field.recovery_rate != null ? `${(Number(field.recovery_rate) * 100).toFixed(0)}%` : "—"}
              </div>
              <div>recovery rate</div>
            </div>
          </div>
          <p className="hint">{String(field.misses_explained ?? "")}</p>
          <h3>Motion-fit self-test</h3>
          <p>
            Synthetic track recovered: {selfTest.ok ? "yes" : "no"} (truth μ≈
            {String(selfTest.truth_pm_ra)}/{String(selfTest.truth_pm_dec)} ″/yr; fit{" "}
            {Number(selfTest.fit_pm_ra).toFixed?.(1) ?? "—"}/{Number(selfTest.fit_pm_dec).toFixed?.(1) ?? "—"} ±
            {selfTest.fit_pm_ra_err != null ? Number(selfTest.fit_pm_ra_err).toFixed(1) : "no σ"}).{" "}
            <span className="badge synth">is_synthetic</span>
          </p>
        </>
      )}
    </section>
  );
}
