import { useEffect, useRef } from "react";

declare global {
  interface Window {
    A?: {
      aladin: (el: HTMLElement, opts: Record<string, unknown>) => AladinInstance;
    };
  }
}

interface AladinInstance {
  gotoRaDec: (ra: number, dec: number) => void;
  setFov: (fovDeg: number) => void;
}

export function AladinOverlay({ ra, dec, fov }: { ra: number; dec: number; fov: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const aladinRef = useRef<AladinInstance | null>(null);

  useEffect(() => {
    const existing = document.querySelector("script[data-aladin]");
    const start = () => {
      if (!ref.current || !window.A) return;
      try {
        aladinRef.current = window.A.aladin(ref.current, {
          survey: "P/DSS2/color",
          fov,
          target: `${ra} ${dec}`,
          showReticle: true,
        });
      } catch {
        /* graceful */
      }
    };
    if (window.A) start();
    else if (!existing) {
      const s = document.createElement("script");
      s.src = "https://aladin.cds.unistra.fr/AladinLite/api/v3/latest/aladin.js";
      s.dataset.aladin = "1";
      s.onload = start;
      document.body.appendChild(s);
    }
  }, []);

  useEffect(() => {
    aladinRef.current?.gotoRaDec(ra, dec);
    aladinRef.current?.setFov(fov);
  }, [ra, dec, fov]);

  return (
    <section className="panel" aria-label="Aladin sky context">
      <h2>Sky context (Aladin Lite)</h2>
      <p className="hint">
        CDS Aladin Lite — toggle surveys in the Aladin UI. Gaia/WISE overlays depend on Aladin catalog
        layers when available. Position/FOV sync with the blink player.
      </p>
      <div ref={ref} className="aladin" style={{ height: 280, width: "100%" }} />
    </section>
  );
}
