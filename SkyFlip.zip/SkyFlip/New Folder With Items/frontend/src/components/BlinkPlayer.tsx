import { useEffect, useRef, useState } from "react";
import type { CutoutFrame, PredictedTrackPoint } from "../types";
import { apiUrl } from "../lib/api";

const MAX_HZ = 3;
const DEFAULT_HZ = 1.5;

interface Props {
  frames: CutoutFrame[];
  ghost?: PredictedTrackPoint[];
  showGhost?: boolean;
  stretch?: string;
  onEpochChange?: (index: number) => void;
  reducedMotion?: boolean;
}

export function BlinkPlayer({
  frames,
  ghost = [],
  showGhost = true,
  onEpochChange,
  reducedMotion = false,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(!reducedMotion);
  const [hz, setHz] = useState(DEFAULT_HZ);
  const [images, setImages] = useState<HTMLImageElement[]>([]);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const loaded: HTMLImageElement[] = [];
      for (const f of frames) {
        const img = new Image();
        img.crossOrigin = "anonymous";
        img.src = apiUrl(f.image_url);
        await img.decode().catch(() => undefined);
        loaded.push(img);
      }
      if (!cancelled) setImages(loaded);
    })();
    return () => {
      cancelled = true;
    };
  }, [frames]);

  useEffect(() => {
    if (!playing || frames.length < 2) return;
    const rate = Math.min(Math.max(hz, 0.2), MAX_HZ);
    const id = window.setInterval(() => {
      setIndex((i) => {
        const n = (i + 1) % frames.length;
        onEpochChange?.(n);
        return n;
      });
    }, 1000 / rate);
    return () => window.clearInterval(id);
  }, [playing, hz, frames.length, onEpochChange]);

  useEffect(() => {
    const c = canvasRef.current;
    if (!c || !images[index]) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    const img = images[index];
    c.width = 480;
    c.height = 480;
    ctx.fillStyle = "#0a1020";
    ctx.fillRect(0, 0, c.width, c.height);
    ctx.save();
    ctx.translate(c.width / 2 + pan.x, c.height / 2 + pan.y);
    ctx.scale(zoom, zoom);
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(img, -c.width / 2, -c.height / 2, c.width, c.height);
    ctx.restore();

    // Ghost marker for this epoch if available
    if (showGhost && ghost[index]) {
      ctx.strokeStyle = "#f0c24b";
      ctx.lineWidth = 2;
      const cx = c.width / 2;
      const cy = c.height / 2;
      ctx.beginPath();
      ctx.arc(cx, cy, 10, 0, Math.PI * 2);
      ctx.stroke();
      ctx.font = "12px IBM Plex Mono, monospace";
      ctx.fillStyle = "#f0c24b";
      ctx.fillText("ghost", cx + 14, cy - 8);
    }

    const f = frames[index];
    ctx.fillStyle = "rgba(6,12,24,0.7)";
    ctx.fillRect(0, c.height - 36, c.width, 36);
    ctx.fillStyle = "#e8eefc";
    ctx.font = "13px IBM Plex Sans, sans-serif";
    ctx.fillText(
      `${f.time_iso || `MJD ${f.mjd.toFixed(3)}`} · ${f.bandpass}` +
        (f.central_wavelength_um != null ? ` · λ≈${f.central_wavelength_um.toFixed(2)} µm` : ""),
      12,
      c.height - 14
    );
  }, [images, index, zoom, pan, ghost, showGhost, frames]);

  const step = (dir: number) => {
    setPlaying(false);
    setIndex((i) => {
      const n = (i + dir + frames.length) % frames.length;
      onEpochChange?.(n);
      return n;
    });
  };

  return (
    <div className="blink" role="region" aria-label="SPHEREx blink player">
      <canvas
        ref={canvasRef}
        tabIndex={0}
        aria-label="Sky cutout blink canvas"
        onKeyDown={(e) => {
          if (e.key === " " || e.key === "k") {
            e.preventDefault();
            setPlaying((p) => !p);
          }
          if (e.key === "ArrowRight") step(1);
          if (e.key === "ArrowLeft") step(-1);
        }}
      />
      <div className="blink-controls">
        <button type="button" onClick={() => setPlaying((p) => !p)} aria-pressed={playing}>
          {playing ? "Pause" : "Play"}
        </button>
        <button type="button" onClick={() => step(-1)}>
          Step −
        </button>
        <button type="button" onClick={() => step(1)}>
          Step +
        </button>
        <label>
          Speed {Math.min(hz, MAX_HZ).toFixed(1)} Hz
          <input
            type="range"
            min={0.5}
            max={MAX_HZ}
            step={0.1}
            value={Math.min(hz, MAX_HZ)}
            onChange={(e) => setHz(Number(e.target.value))}
            aria-valuemax={MAX_HZ}
          />
        </label>
        <label>
          Zoom
          <input
            type="range"
            min={1}
            max={4}
            step={0.1}
            value={zoom}
            onChange={(e) => setZoom(Number(e.target.value))}
          />
        </label>
        <button type="button" onClick={() => setPan({ x: 0, y: 0 })}>
          Reset pan
        </button>
      </div>
      <p className="hint">
        Max blink rate 3 Hz (photosensitivity). Space/K play-pause · arrows step. SPHEREx pixels ≈ 6.15″.
        Larger FOV tracks fast movers but transfers more data.
      </p>
      {frames[index]?.is_synthetic && (
        <div className="badge synth" role="status">
          SIMULATED / TEST DATA
        </div>
      )}
    </div>
  );
}
