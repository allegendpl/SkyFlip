import type { CutoutFrame } from "../types";

export function MetadataPanel({ frame, source }: { frame?: CutoutFrame; source?: string }) {
  if (!frame) return <aside className="panel">No frame selected.</aside>;
  const flags = frame.flag_summary ?? {};
  const top = Object.entries(flags)
    .filter(([k, v]) => k !== "total_pixels" && v > 0)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8);

  return (
    <aside className="panel" aria-label="Frame metadata">
      <h2>Metadata</h2>
      <dl>
        <dt>Source</dt>
        <dd>{source ?? "—"}</dd>
        <dt>Epoch</dt>
        <dd>{frame.time_iso || `MJD ${frame.mjd}`}</dd>
        <dt>Band / detector</dt>
        <dd>
          {frame.bandpass} (D{frame.detector})
        </dd>
        <dt>λ (cutout center)</dt>
        <dd>
          {frame.central_wavelength_um != null
            ? `${frame.central_wavelength_um.toFixed(3)} µm`
            : "no uncertainty / value available"}
        </dd>
        <dt>Obs ID</dt>
        <dd className="mono">{frame.obs_id}</dd>
      </dl>
      <h3>Contamination / quality flags</h3>
      <p className="hint">Pixel counts from FLAGS bitmask (Explanatory Supplement Table 16).</p>
      <ul>
        {top.length === 0 && <li>No flagged pixels summarized.</li>}
        {top.map(([k, v]) => (
          <li key={k}>
            {k}: {v}
          </li>
        ))}
      </ul>
    </aside>
  );
}
