export type DataSource = "live" | "cached-demo";

export interface HealthResponse {
  status: string;
  source: DataSource;
  services: Record<string, { ok: boolean; detail?: string }>;
  demo_cache_available: boolean;
  pixel_scale_arcsec: number;
}

export interface ResolveResponse {
  name: string;
  ra: number;
  dec: number;
  source: DataSource;
  catalog: string;
  uncertainty_arcsec: number | null;
  uncertainty_note: string;
}

export interface CutoutFrame {
  epoch_id: string;
  obs_id: string;
  mjd: number;
  time_iso: string;
  bandpass: string;
  detector: number;
  image_url: string;
  central_wavelength_um?: number | null;
  flag_summary?: Record<string, number>;
  is_synthetic?: boolean;
}

export interface CutoutsResponse {
  ra: number;
  dec: number;
  fov_deg: number;
  frames: CutoutFrame[];
  source: DataSource;
  pixel_scale_arcsec: number;
  note?: string;
}

export interface PredictedTrackPoint {
  epoch_id: string;
  mjd: number;
  ra: number;
  dec: number;
  note?: string;
}

export interface SpectrumPoint {
  wavelength_um: number;
  flux: number;
  flux_err?: number | null;
  detector?: number;
  bandpass?: string;
}

export interface MoverCandidate {
  id: string;
  classification: "known" | "candidate" | "likely_artifact";
  reasons: string[];
  track: { epoch_id: string; mjd: number; ra: number; dec: number; ra_err_arcsec?: number; dec_err_arcsec?: number }[];
  pm_ra_arcsec_yr?: number | null;
  pm_dec_arcsec_yr?: number | null;
  pm_ra_err_arcsec_yr?: number | null;
  pm_dec_err_arcsec_yr?: number | null;
  is_synthetic: boolean;
}

export interface TestTarget {
  id: string;
  name: string;
  ra?: number;
  dec?: number;
  resolve?: boolean;
}

export const WISE0855 = {
  id: "wise0855",
  name: "WISE 0855",
  ra: 133.79512917,
  dec: -7.24514722,
};

export const TEST_TARGETS: TestTarget[] = [
  { id: "barnards_star", name: "Barnard's Star", resolve: true },
  { id: "epsilon_indi_b", name: "Epsilon Indi B", resolve: true },
  WISE0855,
  { id: "rw_aurigae", name: "RW Aurigae", resolve: true },
  { id: "r_draconis", name: "R Draconis", resolve: true },
];
