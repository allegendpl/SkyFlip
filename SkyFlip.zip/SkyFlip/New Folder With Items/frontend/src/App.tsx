import { useEffect, useMemo, useState } from "react";
import { AladinOverlay } from "./components/AladinOverlay";
import { Banner } from "./components/Banner";
import { BlinkPlayer } from "./components/BlinkPlayer";
import { CandidateList } from "./components/CandidateList";
import { ClassroomMode } from "./components/ClassroomMode";
import { DiscoveryMode } from "./components/DiscoveryMode";
import { LimitsPanel } from "./components/LimitsPanel";
import { MetadataPanel } from "./components/MetadataPanel";
import { PlanetXMeter } from "./components/PlanetXMeter";
import { ScoreboardPanel } from "./components/ScoreboardPanel";
import { SearchBar } from "./components/SearchBar";
import { ShareButton } from "./components/ShareButton";
import { SkyTour } from "./components/SkyTour";
import { SpectrumPanel } from "./components/SpectrumPanel";
import { TargetButtons } from "./components/TargetButtons";
import { api } from "./lib/api";
import { loadDemoCutouts } from "./lib/demoData";
import { readUrlState, writeUrlState } from "./lib/urlState";
import type { CutoutsResponse, MoverCandidate, PredictedTrackPoint, SpectrumPoint } from "./types";
import { TEST_TARGETS, WISE0855 } from "./types";
import "./App.css";

type Tab = "viewer" | "scoreboard" | "discovery" | "classroom" | "planetx";

export default function App() {
  const initial = readUrlState();
  const reduced = useMemo(
    () => window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false,
    []
  );
  const embed = Boolean(initial.embed);
  const [tab, setTab] = useState<Tab>((initial.tab as Tab) || "viewer");
  const [ra, setRa] = useState(initial.ra ?? WISE0855.ra);
  const [dec, setDec] = useState(initial.dec ?? WISE0855.dec);
  const [fov, setFov] = useState(initial.fov ?? 0.05);
  const [targetId, setTargetId] = useState(initial.target ?? "wise0855");
  const [name, setName] = useState("WISE 0855");
  const [cutouts, setCutouts] = useState<CutoutsResponse | null>(null);
  const [epoch, setEpoch] = useState(0);
  const [ghost, setGhost] = useState<PredictedTrackPoint[]>([]);
  const [showGhost, setShowGhost] = useState(true);
  const [movers, setMovers] = useState<MoverCandidate[]>([]);
  const [spectrum, setSpectrum] = useState<SpectrumPoint[]>([]);
  const [specNote, setSpecNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [stack, setStack] = useState<"none" | "detector">("none");

  useEffect(() => {
    writeUrlState({
      ra,
      dec,
      fov,
      epoch,
      stretch: "asinh",
      embed,
      demo: initial.demo,
      tab,
      target: targetId,
    });
  }, [ra, dec, fov, epoch, embed, tab, targetId, initial.demo]);

  const loadField = async (opts: {
    ra: number;
    dec: number;
    name?: string;
    target?: string;
  }) => {
    setBusy(true);
    setErr("");
    setRa(opts.ra);
    setDec(opts.dec);
    if (opts.name) setName(opts.name);
    if (opts.target) setTargetId(opts.target);
    try {
      let data: CutoutsResponse;
      try {
        data = await api.cutouts({
          ra: opts.ra,
          dec: opts.dec,
          fov,
          target: opts.target,
          stack,
        });
      } catch {
        const demo = opts.target ? await loadDemoCutouts(opts.target) : null;
        if (!demo) throw new Error("Live data failed and no cached demo available");
        data = demo;
      }
      setCutouts(data);
      setEpoch(0);
      try {
        const g = await api.predictedTrack(opts.ra, opts.dec, opts.name || name);
        setGhost(g.points);
      } catch {
        setGhost([]);
      }
    } catch (e) {
      setErr(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    void loadField({ ra, dec, name, target: targetId });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Demo auto-walk
  useEffect(() => {
    if (!initial.demo) return;
    let i = 0;
    const id = window.setInterval(() => {
      const t = TEST_TARGETS[i % TEST_TARGETS.length];
      i += 1;
      void (async () => {
        if (t.ra != null && t.dec != null) {
          await loadField({ ra: t.ra, dec: t.dec, name: t.name, target: t.id });
        } else {
          const r = await api.resolve(t.name);
          await loadField({ ra: r.ra, dec: r.dec, name: t.name, target: t.id });
        }
      })();
    }, 12000);
    return () => window.clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initial.demo]);

  const exportCandidates = () => {
    const payload = {
      ra,
      dec,
      fov,
      movers,
      credit: "NASA/JPL-Caltech/IPAC — SPHEREx at IRSA. SkyFlip candidates only.",
      disclaimer: "Not a discovery claim.",
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "skyflip_candidates.json";
    a.click();
  };

  return (
    <div className={`app ${embed ? "embed" : ""}`}>
      {!embed && (
        <header className="hero">
          <div>
            <p className="brand">SkyFlip</p>
            <p className="tag">
              The blink comparator that found Pluto, rebuilt for everyone — with proof built in.
            </p>
          </div>
          <nav className="tabs" aria-label="Primary">
            {(
              [
                ["viewer", "Viewer"],
                ["scoreboard", "Scoreboard"],
                ["discovery", "Discovery"],
                ["classroom", "Classroom"],
                ["planetx", "Planet X meter"],
              ] as const
            ).map(([id, label]) => (
              <button key={id} type="button" className={tab === id ? "active" : ""} onClick={() => setTab(id)}>
                {label}
              </button>
            ))}
          </nav>
        </header>
      )}

      <Banner
        cached={cutouts?.source === "cached-demo"}
        synthetic={cutouts?.frames.some((f) => f.is_synthetic)}
      />

      {tab === "viewer" && (
        <main className="layout">
          <section className="primary">
            {!embed && (
              <>
                <SearchBar
                  onGoto={(r, d, n) => void loadField({ ra: r, dec: d, name: n, target: targetId })}
                />
                <TargetButtons
                  onSelect={(t) => void loadField({ ra: t.ra, dec: t.dec, name: t.name, target: t.id })}
                />
                <div className="row wrap">
                  <label>
                    FOV {fov.toFixed(3)}°
                    <input
                      type="range"
                      min={0.02}
                      max={0.2}
                      step={0.01}
                      value={fov}
                      onChange={(e) => setFov(Number(e.target.value))}
                    />
                  </label>
                  <label>
                    Stack
                    <select value={stack} onChange={(e) => setStack(e.target.value as "none" | "detector")}>
                      <option value="none">none</option>
                      <option value="detector">detector (S/N)</option>
                    </select>
                  </label>
                  <button type="button" disabled={busy} onClick={() => void loadField({ ra, dec, name, target: targetId })}>
                    {busy ? "Loading…" : "Reload"}
                  </button>
                  <label className="check">
                    <input type="checkbox" checked={showGhost} onChange={(e) => setShowGhost(e.target.checked)} />
                    Ghost track
                  </label>
                  <ShareButton state={{ ra, dec, fov, target: targetId, stretch: "asinh" }} />
                  <button
                    type="button"
                    onClick={() =>
                      void api.movers(ra, dec, fov).then((r) => setMovers(r.movers)).catch((e) => setErr(String(e)))
                    }
                  >
                    Detect movers
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      void api
                        .spectrum(ra, dec)
                        .then((r) => {
                          setSpectrum(r.points);
                          setSpecNote(r.method_note);
                        })
                        .catch((e) => setErr(String(e)))
                    }
                  >
                    Load spectrum
                  </button>
                  <button type="button" onClick={exportCandidates}>
                    Export candidates JSON
                  </button>
                </div>
              </>
            )}
            {err && <p className="error" role="alert">{err}</p>}
            {cutouts && (
              <BlinkPlayer
                frames={cutouts.frames}
                ghost={ghost}
                showGhost={showGhost}
                reducedMotion={reduced}
                onEpochChange={setEpoch}
              />
            )}
            {!cutouts && busy && <div className="skeleton" aria-busy="true" />}
          </section>
          <aside className="side">
            <MetadataPanel frame={cutouts?.frames[epoch]} source={cutouts?.source} />
            <CandidateList movers={movers} />
            <SpectrumPanel points={spectrum} methodNote={specNote} />
            {!embed && <AladinOverlay ra={ra} dec={dec} fov={Math.max(fov, 0.2)} />}
            {!embed && <SkyTour onPick={(id) => {
              const t = TEST_TARGETS.find((x) => x.id === id);
              if (!t) return;
              if (t.ra != null && t.dec != null) void loadField({ ra: t.ra, dec: t.dec, name: t.name, target: t.id });
              else void api.resolve(t.name).then((r) => loadField({ ra: r.ra, dec: r.dec, name: t.name, target: t.id }));
            }} />}
          </aside>
        </main>
      )}

      {tab === "scoreboard" && (
        <main className="single">
          <ScoreboardPanel />
          <LimitsPanel />
        </main>
      )}
      {tab === "discovery" && (
        <main className="single">
          <DiscoveryMode />
        </main>
      )}
      {tab === "classroom" && (
        <main className="single">
          <ClassroomMode />
        </main>
      )}
      {tab === "planetx" && (
        <main className="single">
          <PlanetXMeter />
        </main>
      )}

      {!embed && (
        <footer>
          <p>
            Credits: NASA / JPL-Caltech / IPAC SPHEREx archive. MIT license. We do not claim to discover
            Planet X.
          </p>
        </footer>
      )}
    </div>
  );
}
