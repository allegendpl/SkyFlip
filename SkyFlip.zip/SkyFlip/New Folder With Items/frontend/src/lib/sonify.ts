/** Spectrum sonification (not a real telescope sound). */

export interface SonifyPoint {
  wavelength_um: number;
  flux: number;
}

export function describeSonification(points: SonifyPoint[]): string {
  if (!points.length) return "No spectrum loaded to sonify.";
  const lo = points[0].wavelength_um;
  const hi = points[points.length - 1].wavelength_um;
  return `Sonification: wavelength from ${lo.toFixed(2)} to ${hi.toFixed(2)} µm mapped to pitch; flux mapped to volume. This is an auditory display, not a physical sound from the sky.`;
}

export async function playSpectrum(
  points: SonifyPoint[],
  opts: { volume?: number; durationSec?: number; signal?: AbortSignal } = {}
): Promise<void> {
  if (!points.length) return;
  const volume = opts.volume ?? 0.2;
  const durationSec = opts.durationSec ?? Math.min(8, points.length * 0.45);
  const ctx = new AudioContext();
  const gain = ctx.createGain();
  gain.gain.value = volume;
  gain.connect(ctx.destination);

  const fluxes = points.map((p) => p.flux);
  const fmin = Math.min(...fluxes);
  const fmax = Math.max(...fluxes) || fmin + 1;
  const t0 = ctx.currentTime;
  const dt = durationSec / points.length;

  for (let i = 0; i < points.length; i++) {
    if (opts.signal?.aborted) break;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    const frac = i / Math.max(points.length - 1, 1);
    const freq = 220 * Math.pow(2, frac * 2); // 2 octaves
    const amp = volume * (0.05 + 0.95 * ((points[i].flux - fmin) / (fmax - fmin)));
    osc.frequency.value = freq;
    osc.type = "sine";
    g.gain.value = 0;
    osc.connect(g);
    g.connect(gain);
    const start = t0 + i * dt;
    g.gain.setValueAtTime(0, start);
    g.gain.linearRampToValueAtTime(amp, start + 0.02);
    g.gain.linearRampToValueAtTime(0, start + dt * 0.9);
    osc.start(start);
    osc.stop(start + dt);
  }

  await new Promise<void>((resolve) => {
    const id = window.setTimeout(() => resolve(), durationSec * 1000 + 100);
    opts.signal?.addEventListener("abort", () => {
      window.clearTimeout(id);
      void ctx.close();
      resolve();
    });
  });
  await ctx.close();
}
