import type { CutoutFrame, CutoutsResponse } from "../types";

export async function loadDemoCutouts(targetId: string): Promise<CutoutsResponse | null> {
  try {
    const r = await fetch(`/demo-data/${targetId}/manifest.json`);
    if (!r.ok) return null;
    const man = await r.json();
    const frames: CutoutFrame[] = (man.frames ?? []).map((f: Record<string, unknown>) => ({
      epoch_id: String(f.epoch_id),
      obs_id: String(f.obs_id ?? ""),
      mjd: Number(f.mjd),
      time_iso: String(f.time_iso ?? ""),
      bandpass: String(f.bandpass ?? "SPHEREx-D1"),
      detector: Number(f.detector ?? 1),
      image_url: `/demo-data/${targetId}/${f.png}`,
      central_wavelength_um: f.central_wavelength_um as number | undefined,
      flag_summary: (f.flag_summary as Record<string, number>) ?? {},
      is_synthetic: Boolean(man.is_synthetic),
    }));
    return {
      ra: man.ra,
      dec: man.dec,
      fov_deg: man.fov_deg ?? 0.05,
      frames,
      source: "cached-demo",
      pixel_scale_arcsec: man.pixel_scale_arcsec ?? 6.15,
      note: "Using cached demo data",
    };
  } catch {
    return null;
  }
}
