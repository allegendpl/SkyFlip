import type {
  CutoutsResponse,
  HealthResponse,
  MoverCandidate,
  PredictedTrackPoint,
  ResolveResponse,
  SpectrumPoint,
} from "../types";

const API = import.meta.env.VITE_API_URL ?? "http://127.0.0.1:8000";

async function getJson<T>(path: string): Promise<T> {
  const r = await fetch(`${API}${path}`);
  if (!r.ok) {
    const text = await r.text();
    throw new Error(`${r.status} ${text}`);
  }
  return r.json() as Promise<T>;
}

export function apiUrl(path: string): string {
  if (path.startsWith("/demo-data")) return path;
  if (path.startsWith("http")) return path;
  return `${API}${path}`;
}

export const api = {
  health: () => getJson<HealthResponse>("/api/health"),
  resolve: (name: string) => getJson<ResolveResponse>(`/api/resolve?name=${encodeURIComponent(name)}`),
  cutouts: (p: {
    ra: number;
    dec: number;
    fov: number;
    bandpass?: string;
    target?: string;
    stack?: string;
  }) => {
    const q = new URLSearchParams({
      ra: String(p.ra),
      dec: String(p.dec),
      fov: String(p.fov),
      bandpass: p.bandpass ?? "SPHEREx-D1",
    });
    if (p.target) q.set("target", p.target);
    if (p.stack) q.set("stack", p.stack);
    return getJson<CutoutsResponse>(`/api/cutouts?${q}`);
  },
  predictedTrack: (ra: number, dec: number, name: string) =>
    getJson<{ points: PredictedTrackPoint[]; method: string; pixel_scale_arcsec: number }>(
      `/api/predicted-track?ra=${ra}&dec=${dec}&name=${encodeURIComponent(name)}`
    ),
  movers: (ra: number, dec: number, fov: number) =>
    getJson<{ movers: MoverCandidate[] }>(`/api/movers?ra=${ra}&dec=${dec}&fov=${fov}`),
  spectrum: (ra: number, dec: number) =>
    getJson<{ points: SpectrumPoint[]; method_note: string; unit: string }>(
      `/api/spectrum?ra=${ra}&dec=${dec}`
    ),
  scoreboard: () => getJson<{ results: Record<string, unknown>; explanation: string; source: string }>(
    "/api/scoreboard"
  ),
  postVote: async (candidate_id: string, vote: string) => {
    const q = new URLSearchParams({ candidate_id, vote });
    const r = await fetch(`${API}/api/votes?${q}`, { method: "POST" });
    return r.json();
  },
};
