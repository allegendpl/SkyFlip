export interface UrlState {
  ra?: number;
  dec?: number;
  fov?: number;
  epoch?: number;
  stretch?: string;
  embed?: boolean;
  demo?: boolean;
  tab?: string;
  target?: string;
}

export function readUrlState(): UrlState {
  const p = new URLSearchParams(window.location.search);
  const num = (k: string) => {
    const v = p.get(k);
    return v != null && v !== "" ? Number(v) : undefined;
  };
  return {
    ra: num("ra"),
    dec: num("dec"),
    fov: num("fov"),
    epoch: num("epoch"),
    stretch: p.get("stretch") ?? undefined,
    embed: p.get("embed") === "1",
    demo: p.get("demo") === "1",
    tab: p.get("tab") ?? undefined,
    target: p.get("target") ?? undefined,
  };
}

export function writeUrlState(state: UrlState): void {
  const p = new URLSearchParams(window.location.search);
  const set = (k: string, v: string | number | boolean | undefined) => {
    if (v === undefined || v === false || v === "") p.delete(k);
    else p.set(k, String(v === true ? "1" : v));
  };
  set("ra", state.ra);
  set("dec", state.dec);
  set("fov", state.fov);
  set("epoch", state.epoch);
  set("stretch", state.stretch);
  set("embed", state.embed);
  set("demo", state.demo);
  set("tab", state.tab);
  set("target", state.target);
  const qs = p.toString();
  const url = `${window.location.pathname}${qs ? `?${qs}` : ""}`;
  window.history.replaceState({}, "", url);
}

export function shareUrl(state: UrlState): string {
  const u = new URL(window.location.href);
  const next = { ...readUrlState(), ...state };
  writeUrlState(next);
  return u.origin + u.pathname + "?" + new URLSearchParams({
    ...(next.ra != null ? { ra: String(next.ra) } : {}),
    ...(next.dec != null ? { dec: String(next.dec) } : {}),
    ...(next.fov != null ? { fov: String(next.fov) } : {}),
    ...(next.stretch ? { stretch: next.stretch } : {}),
    ...(next.target ? { target: next.target } : {}),
  }).toString();
}
