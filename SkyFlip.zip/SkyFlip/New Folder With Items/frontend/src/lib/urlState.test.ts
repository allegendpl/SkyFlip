/** Lightweight URL state sanity check (run via node --experimental-strip-types if desired). */
import { readUrlState, writeUrlState } from "./urlState";

export function smokeUrlRoundTrip(): boolean {
  writeUrlState({ ra: 133.79, dec: -7.24, fov: 0.05, stretch: "asinh", target: "wise0855" });
  const s = readUrlState();
  return s.ra === 133.79 && s.dec === -7.24 && s.target === "wise0855";
}
