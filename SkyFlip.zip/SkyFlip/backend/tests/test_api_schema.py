"""API schema smoke tests (TestClient, mocked IRSA where needed)."""

from __future__ import annotations

from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_health_schema():
    r = client.get("/api/health")
    assert r.status_code == 200
    body = r.json()
    assert "status" in body
    assert "services" in body
    assert "demo_cache_available" in body
    assert body["pixel_scale_arcsec"] == 6.15
    assert body["source"] in ("live", "cached-demo")
