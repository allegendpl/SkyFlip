"""Catalog adapters (SIMBAD/Sesame, Gaia, JPL). Phase 0: name resolve + pings."""

from __future__ import annotations

from typing import Any

from astropy.coordinates import SkyCoord
from astropy.coordinates.name_resolve import NameResolveError


class CatalogAdapterError(RuntimeError):
    pass


def resolve_name(name: str) -> dict[str, Any]:
    """
    Resolve an object name to ICRS RA/Dec.

    Uses Astropy ``SkyCoord.from_name`` (CDS Sesame → SIMBAD/NED/VizieR).
    Preferred over raw astroquery.Simbad TAP here because the SIMBAD
    capabilities endpoint currently 404s for some astroquery versions.
    """
    try:
        coord = SkyCoord.from_name(name)
    except NameResolveError as exc:
        raise CatalogAdapterError(f"No match for {name!r}: {exc}") from exc
    except Exception as exc:
        raise CatalogAdapterError(f"Name resolve failed for {name!r}: {exc}") from exc

    return {
        "name": name,
        "ra": float(coord.ra.deg),
        "dec": float(coord.dec.deg),
        "catalog": "Sesame/SIMBAD",
        "source": "live",
        "uncertainty_arcsec": None,
        "uncertainty_note": "Sesame/SIMBAD coordinates; no separate uncertainty provided by resolver",
    }


def ping_simbad() -> dict[str, Any]:
    try:
        resolve_name("Sirius")
        return {"ok": True}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def ping_jpl() -> dict[str, Any]:
    """Phase 0: connectivity probe only (Horizons)."""
    import requests

    try:
        r = requests.get(
            "https://ssd.jpl.nasa.gov/api/horizons.api",
            params={"format": "json", "COMMAND": "'1'", "OBJ_DATA": "'YES'", "MAKE_EPHEM": "'NO'"},
            timeout=30,
        )
        return {"ok": r.status_code == 200, "status_code": r.status_code}
    except requests.RequestException as exc:
        return {"ok": False, "error": str(exc)}
