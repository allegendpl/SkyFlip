"""
SPHEREx / IRSA data adapter.

ALL live SPHEREx I/O belongs here. Endpoints, MEF layout, and flag bits are
taken from verified IRSA documentation — see docs/DATA_NOTES.md.
Do not invent FITS extension names or API paths.
"""

from __future__ import annotations

import hashlib
import logging
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Optional
from urllib.parse import urlencode

import numpy as np
import requests
from astropy.io import fits
from astropy.time import Time
from astropy.wcs import WCS
from astropy.utils.data import conf as astropy_data_conf

# IRSA cutouts can exceed the default remote timeout.
astropy_data_conf.remote_timeout = 180

logger = logging.getLogger(__name__)

IRSA_TAP_SYNC = "https://irsa.ipac.caltech.edu/TAP/sync"
IRSA_SIA = "https://irsa.ipac.caltech.edu/SIA"
IRSA_BASE = "https://irsa.ipac.caltech.edu/"

# Verified SIA2 collections (IRSA Data Access, 2026-11-12).
SIA_COLLECTIONS_WIDE = ("spherex_dr1", "spherex_qr3")
SIA_COLLECTIONS_DEEP = ("spherex_dr1_deep", "spherex_qr3_deep")

# Verified bandpass names in TAP/SIA.
BANDPASSES = tuple(f"SPHEREx-D{i}" for i in range(1, 7))

# Pixel scale from Explanatory Supplement / live SIA s_pixel_scale.
PIXEL_SCALE_ARCSEC = 6.15

# FLAGS bit names from Explanatory Supplement Table 16 / IRSA intro notebook.
# Values are bit indices (flag value = 1 << bit).
FLAG_BITS: dict[str, int] = {
    "TRANSIENT": 0,
    "OVERFLOW": 1,
    "SUR_ERROR": 2,
    "NONFUNC": 6,
    "DICHROIC": 7,
    "MISSING_DATA": 9,
    "HOT": 10,
    "COLD": 11,
    "FULLSAMPLE": 12,
    "PHANMISS": 14,
    "NONLINEAR": 15,
    "PERSIST": 17,
    "OUTLIER": 19,
    "SOURCE": 21,
    "GHOST": 22,
    "GHOST_FPA": 23,  # listed in IRSA intro notebook
    "GHOST_EXT": 24,
    "STREAK": 25,  # listed in IRSA intro notebook
    "BLOOM": 26,
    "SNOWBALL": 27,
    "HALO": 28,
    "SATELLITE_HALO": 29,
}

DEFAULT_CACHE_DIR = Path(
    os.environ.get("SKYFLIP_CACHE_DIR", Path(__file__).resolve().parents[3] / "backend" / ".cache")
)


@dataclass
class SpherexObservation:
    """One Spectral Image covering a position (one detector / bandpass)."""

    obs_id: str
    bandpass: str
    detector: int
    mjd: float
    access_url: str
    cutout_url: str
    collection: str = ""
    time_iso: str = ""
    s_pixel_scale_arcsec: Optional[float] = None
    source: str = "live"

    def to_dict(self) -> dict[str, Any]:
        return {
            "obs_id": self.obs_id,
            "bandpass": self.bandpass,
            "detector": self.detector,
            "mjd": self.mjd,
            "time_iso": self.time_iso,
            "access_url": self.access_url,
            "cutout_url": self.cutout_url,
            "collection": self.collection,
            "s_pixel_scale_arcsec": self.s_pixel_scale_arcsec,
            "source": self.source,
        }


@dataclass
class SpherexCutout:
    """Parsed cutout MEF for one observation."""

    observation: SpherexObservation
    image: np.ndarray
    flags: np.ndarray
    variance: Optional[np.ndarray]
    zodi: Optional[np.ndarray]
    wcs: WCS
    central_wavelength_um: Optional[float]
    bandwidth_um: Optional[float]
    header_meta: dict[str, Any] = field(default_factory=dict)
    flag_summary: dict[str, int] = field(default_factory=dict)
    fits_path: Optional[Path] = None
    source: str = "live"


class SpherexAdapterError(RuntimeError):
    pass


def _detector_from_bandpass(bandpass: str) -> int:
    m = re.search(r"D([1-6])$", bandpass or "")
    if not m:
        raise SpherexAdapterError(f"Unrecognized bandpass: {bandpass!r}")
    return int(m.group(1))


def _mjd_to_iso(mjd: float) -> str:
    try:
        return Time(mjd, format="mjd", scale="utc").isot
    except Exception:
        return ""


def build_cutout_url(access_url: str, ra: float, dec: float, size_deg: float) -> str:
    """Append IBE cutout query string (verified IRSA cutout docs)."""
    base = access_url.split("?")[0]
    # Official notebook uses center=ra,dec d&size=...
    qs = urlencode({"center": f"{ra},{dec}d", "size": f"{size_deg}"})
    return f"{base}?{qs}"


def summarize_flags(flags: np.ndarray) -> dict[str, int]:
    """Count pixels with each named flag bit set."""
    arr = np.asarray(flags)
    out: dict[str, int] = {}
    for name, bit in FLAG_BITS.items():
        mask = (arr.astype(np.uint64) & (1 << bit)) != 0
        out[name] = int(np.count_nonzero(mask))
    out["any_flagged"] = int(np.count_nonzero(arr != 0))
    out["total_pixels"] = int(arr.size)
    return out


class SpherexAdapter:
    """Single module for SPHEREx discovery + cutout fetch + MEF parse."""

    def __init__(
        self,
        cache_dir: Path | str | None = None,
        session: requests.Session | None = None,
        timeout: float = 180.0,
        include_deep: bool = False,
    ) -> None:
        self.cache_dir = Path(cache_dir) if cache_dir else DEFAULT_CACHE_DIR
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.session = session or requests.Session()
        self.timeout = timeout
        self.include_deep = include_deep

    # ------------------------------------------------------------------ health
    def ping_irsa(self) -> dict[str, Any]:
        """Lightweight connectivity check against IRSA TAP."""
        try:
            r = self.session.get(
                IRSA_TAP_SYNC,
                params={
                    "QUERY": "SELECT TOP 1 obs_id FROM spherex.obscore",
                    "FORMAT": "csv",
                },
                timeout=min(30.0, self.timeout),
            )
            ok = r.status_code == 200 and "obs_id" in r.text
            return {"ok": ok, "status_code": r.status_code, "endpoint": IRSA_TAP_SYNC}
        except requests.RequestException as exc:
            return {"ok": False, "error": str(exc), "endpoint": IRSA_TAP_SYNC}

    # --------------------------------------------------------------- discovery
    def find_observations(
        self,
        ra: float,
        dec: float,
        *,
        fov_deg: float = 0.05,
        bandpasses: Iterable[str] | None = None,
        max_rows: int = 500,
    ) -> list[SpherexObservation]:
        """
        Find Spectral Images covering (ra, dec).

        Primary path: TAP artifact+plane (freshest after weekly ingest).
        Fallback: SIA2 for wide (and optionally deep) collections.
        """
        bands = tuple(bandpasses) if bandpasses else BANDPASSES
        try:
            obs = self._find_via_tap(ra, dec, fov_deg=fov_deg, bandpasses=bands, max_rows=max_rows)
            if obs:
                return obs
            logger.warning("TAP returned no rows; falling back to SIA2")
        except Exception as exc:
            logger.warning("TAP discovery failed (%s); falling back to SIA2", exc)

        return self._find_via_sia(ra, dec, radius_deg=max(fov_deg, 0.05), bandpasses=bands)

    def _find_via_tap(
        self,
        ra: float,
        dec: float,
        *,
        fov_deg: float,
        bandpasses: tuple[str, ...],
        max_rows: int,
    ) -> list[SpherexObservation]:
        # energy_bandpassname IN (...) — verified names SPHEREx-D1..D6
        band_list = ", ".join(f"'{b}'" for b in bandpasses)
        query = f"""
SELECT TOP {int(max_rows)}
  'https://irsa.ipac.caltech.edu/' || a.uri AS access_url,
  'https://irsa.ipac.caltech.edu/' || a.uri
    || '?center={ra},{dec}d&size={fov_deg}' AS cutout_url,
  p.time_bounds_lower AS mjd,
  p.energy_bandpassname AS bandpass,
  a.uri AS uri
FROM spherex.artifact a
JOIN spherex.plane p ON a.planeid = p.planeid
WHERE 1 = CONTAINS(POINT('ICRS', {ra}, {dec}), p.poly)
  AND p.energy_bandpassname IN ({band_list})
ORDER BY p.time_bounds_lower
""".strip()

        table = self._tap_csv(query)
        out: list[SpherexObservation] = []
        for row in table:
            bandpass = row.get("bandpass") or row.get("energy_bandpassname") or ""
            access = row["access_url"].strip().strip('"')
            cutout = row.get("cutout_url", "").strip().strip('"') or build_cutout_url(
                access, ra, dec, fov_deg
            )
            mjd = float(row["mjd"])
            uri = row.get("uri", "")
            obs_id = self._obs_id_from_uri(uri) or Path(access.split("?")[0]).stem
            detector = _detector_from_bandpass(bandpass)
            out.append(
                SpherexObservation(
                    obs_id=obs_id,
                    bandpass=bandpass,
                    detector=detector,
                    mjd=mjd,
                    access_url=access,
                    cutout_url=cutout,
                    collection=self._collection_from_uri(uri or access),
                    time_iso=_mjd_to_iso(mjd),
                    s_pixel_scale_arcsec=PIXEL_SCALE_ARCSEC,
                    source="live",
                )
            )
        return out

    def _find_via_sia(
        self,
        ra: float,
        dec: float,
        *,
        radius_deg: float,
        bandpasses: tuple[str, ...],
    ) -> list[SpherexObservation]:
        collections = list(SIA_COLLECTIONS_WIDE)
        if self.include_deep:
            collections.extend(SIA_COLLECTIONS_DEEP)

        band_set = set(bandpasses)
        out: list[SpherexObservation] = []
        for collection in collections:
            params = {
                "COLLECTION": collection,
                "POS": f"circle {ra} {dec} {radius_deg}",
                "RESPONSEFORMAT": "csv",
            }
            r = self.session.get(IRSA_SIA, params=params, timeout=self.timeout)
            r.raise_for_status()
            rows = self._parse_csv(r.text)
            for row in rows:
                bandpass = row.get("energy_bandpassname", "")
                if band_set and bandpass not in band_set:
                    continue
                access = row["access_url"].strip().strip('"')
                if "/ibe/data/" not in access:
                    # Only IBE URLs support the verified cutout query string.
                    continue
                mjd = float(row.get("t_min") or 0.0)
                scale = row.get("s_pixel_scale")
                out.append(
                    SpherexObservation(
                        obs_id=row.get("obs_id", Path(access).stem),
                        bandpass=bandpass,
                        detector=_detector_from_bandpass(bandpass),
                        mjd=mjd,
                        access_url=access,
                        cutout_url=build_cutout_url(access, ra, dec, radius_deg),
                        collection=row.get("obs_collection") or collection,
                        time_iso=_mjd_to_iso(mjd),
                        s_pixel_scale_arcsec=float(scale) if scale else PIXEL_SCALE_ARCSEC,
                        source="live",
                    )
                )
        out.sort(key=lambda o: (o.mjd, o.detector))
        return out

    # ----------------------------------------------------------------- cutouts
    def fetch_cutout(
        self,
        observation: SpherexObservation,
        *,
        force: bool = False,
        subtract_zodi: bool = False,
    ) -> SpherexCutout:
        """Download (or cache-hit) a cutout MEF and parse IMAGE/FLAGS/VARIANCE/ZODI/WCS-WAVE."""
        path = self._cache_path(observation.cutout_url)
        if force or not path.exists():
            self._download(observation.cutout_url, path)

        return self.parse_cutout_fits(path, observation, subtract_zodi=subtract_zodi)

    def parse_cutout_fits(
        self,
        path: Path | str,
        observation: SpherexObservation | None = None,
        *,
        subtract_zodi: bool = False,
        target_ra: float | None = None,
        target_dec: float | None = None,
    ) -> SpherexCutout:
        path = Path(path)
        with fits.open(path) as hdul:
            # Verified HDU order: 0 PRIMARY, 1 IMAGE, 2 FLAGS, 3 VARIANCE, 4 ZODI, 5 EPSF/PSF, 6 WCS-WAVE
            image_hdu = self._hdu_by_name(hdul, "IMAGE", fallback_index=1)
            flags_hdu = self._hdu_by_name(hdul, "FLAGS", fallback_index=2)
            var_hdu = self._hdu_by_name(hdul, "VARIANCE", fallback_index=3, required=False)
            zodi_hdu = self._hdu_by_name(hdul, "ZODI", fallback_index=4, required=False)

            image = np.asarray(image_hdu.data, dtype=np.float64)
            flags = np.asarray(flags_hdu.data)
            variance = np.asarray(var_hdu.data, dtype=np.float64) if var_hdu is not None else None
            zodi = np.asarray(zodi_hdu.data, dtype=np.float64) if zodi_hdu is not None else None

            if subtract_zodi and zodi is not None:
                image = image - zodi

            spatial_wcs = WCS(image_hdu.header)

            wave_um: Optional[float] = None
            bw_um: Optional[float] = None
            # Wavelength at target (or cutout center) via spectral WCS key "W"
            # as demonstrated in IRSA cutouts notebook.
            try:
                if target_ra is not None and target_dec is not None:
                    from astropy.coordinates import SkyCoord
                    import astropy.units as u

                    coord = SkyCoord(target_ra * u.deg, target_dec * u.deg, frame="icrs")
                    x, y = spatial_wcs.world_to_pixel(coord)
                else:
                    y, x = (np.array(image.shape) - 1) / 2.0

                spectral_wcs = WCS(image_hdu.header, fobj=hdul, key="W")
                spectral_wcs.sip = None
                wave_world = spectral_wcs.pixel_to_world(x, y)
                # Returns wavelength Quantity (and optionally bandwidth depending on WCS)
                if hasattr(wave_world, "to"):
                    wave_um = float(wave_world.to("micron").value)
                elif isinstance(wave_world, (tuple, list)) and len(wave_world) >= 1:
                    wave_um = float(wave_world[0].to("micron").value)
                    if len(wave_world) >= 2 and hasattr(wave_world[1], "to"):
                        bw_um = float(wave_world[1].to("micron").value)
            except Exception as exc:
                logger.info("Could not evaluate spectral WCS at target: %s", exc)

            primary = hdul[0].header
            meta = {
                "VERSION": primary.get("VERSION") or image_hdu.header.get("VERSION"),
                "DATE-OBS": image_hdu.header.get("DATE-OBS") or primary.get("DATE-OBS"),
                "MJD-OBS": image_hdu.header.get("MJD-OBS") or primary.get("MJD-OBS"),
                "TELESCOP": image_hdu.header.get("TELESCOP") or primary.get("TELESCOP"),
                "INSTRUME": image_hdu.header.get("INSTRUME") or primary.get("INSTRUME"),
                "BUNIT": image_hdu.header.get("BUNIT"),
                "NAXIS1": int(image_hdu.header.get("NAXIS1") or image.shape[1]),
                "NAXIS2": int(image_hdu.header.get("NAXIS2") or image.shape[0]),
                "FINAST": image_hdu.header.get("FINAST") or primary.get("FINAST"),
            }

            if observation is None:
                observation = SpherexObservation(
                    obs_id=path.stem,
                    bandpass="UNKNOWN",
                    detector=0,
                    mjd=float(meta.get("MJD-OBS") or 0.0),
                    access_url="",
                    cutout_url="",
                    time_iso=str(meta.get("DATE-OBS") or ""),
                    source="live",
                )

            return SpherexCutout(
                observation=observation,
                image=image,
                flags=flags,
                variance=variance,
                zodi=zodi,
                wcs=spatial_wcs,
                central_wavelength_um=wave_um,
                bandwidth_um=bw_um,
                header_meta=meta,
                flag_summary=summarize_flags(flags),
                fits_path=path,
                source=observation.source,
            )

    # ----------------------------------------------------------------- helpers
    def _tap_csv(self, query: str) -> list[dict[str, str]]:
        r = self.session.get(
            IRSA_TAP_SYNC,
            params={"QUERY": query, "FORMAT": "csv"},
            timeout=self.timeout,
        )
        r.raise_for_status()
        if r.text.lstrip().startswith("<") or "ERROR" in r.text.splitlines()[0:3]:
            # TAP error pages sometimes return 200 with ERROR in body
            if "ERROR" in r.text[:500]:
                raise SpherexAdapterError(f"TAP error: {r.text[:500]}")
        return self._parse_csv(r.text)

    @staticmethod
    def _parse_csv(text: str) -> list[dict[str, str]]:
        import csv
        from io import StringIO

        # Skip VOTable/HTML error bodies
        if not text.strip() or "<" in text[:50]:
            return []
        reader = csv.DictReader(StringIO(text))
        return [dict(row) for row in reader]

    @staticmethod
    def _hdu_by_name(hdul: fits.HDUList, name: str, fallback_index: int, required: bool = True):
        if name in hdul:
            return hdul[name]
        if fallback_index < len(hdul):
            return hdul[fallback_index]
        if required:
            raise SpherexAdapterError(f"Missing HDU {name!r} (index {fallback_index})")
        return None

    @staticmethod
    def _obs_id_from_uri(uri: str) -> str:
        # .../level2_2025W19_1B_0241_1D1_spx_....fits → 2025W19_1B_0241_1
        m = re.search(r"level2_([^/]+?)D[1-6]_spx_", uri)
        if m:
            return m.group(1)
        return ""

    @staticmethod
    def _collection_from_uri(uri: str) -> str:
        if "/dr1/" in uri:
            return "spherex_dr1"
        if "/qr3/" in uri:
            return "spherex_qr3"
        if "/qr2/" in uri:
            return "spherex_qr2"
        return ""

    def _cache_path(self, url: str) -> Path:
        digest = hashlib.sha256(url.encode("utf-8")).hexdigest()[:24]
        stem = Path(url.split("?")[0]).stem
        return self.cache_dir / "cutouts" / f"{stem}_{digest}.fits"

    def _download(self, url: str, path: Path, retries: int = 4) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".part")
        last_err: Exception | None = None
        for attempt in range(1, retries + 1):
            try:
                logger.info("Downloading cutout (attempt %s/%s) %s", attempt, retries, url)
                with self.session.get(url, stream=True, timeout=self.timeout) as r:
                    if r.status_code in (429, 502, 503, 504):
                        raise requests.HTTPError(f"{r.status_code} for {url}", response=r)
                    r.raise_for_status()
                    with open(tmp, "wb") as f:
                        for chunk in r.iter_content(chunk_size=1 << 20):
                            if chunk:
                                f.write(chunk)
                if tmp.stat().st_size < 1000:
                    raise SpherexAdapterError(f"Cutout too small ({tmp.stat().st_size} B): {url}")
                tmp.replace(path)
                return
            except (requests.RequestException, SpherexAdapterError, OSError) as exc:
                last_err = exc
                logger.warning("Cutout download failed (%s); retrying…", exc)
                import time

                time.sleep(min(2 ** attempt, 20))
        raise SpherexAdapterError(f"Failed to download cutout after {retries} tries: {last_err}")
