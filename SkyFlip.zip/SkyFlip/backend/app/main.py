"""SkyFlip FastAPI application."""

from __future__ import annotations

import io
import json
import logging
import sqlite3
from pathlib import Path
from typing import Any, Literal, Optional

import numpy as np
from astropy.coordinates import SkyCoord
from astropy.time import Time
import astropy.units as u
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response, FileResponse
from PIL import Image

from .adapters import catalogs, spherex
from .adapters.spherex import PIXEL_SCALE_ARCSEC
from .cache import DEMO_DATA, demo_data_available, read_json, write_json, cache_root
from .classify import classify_track
from .detect import detect_sources, link_detections
from .imaging import Frame, align_frames, difference, stretch, stack_mean
from .models import (
    Classification,
    CutoutFrameMeta,
    CutoutsResponse,
    DataSource,
    DiffResponse,
    EpochInfo,
    EpochsResponse,
    HealthResponse,
    HealthServiceStatus,
    MoverCandidate,
    MoversResponse,
    MoverTrackPoint,
    PredictedTrackPoint,
    PredictedTrackResponse,
    ResolveResponse,
    ScoreboardResponse,
    SpectrumPoint,
    SpectrumResponse,
)
from . import spectra, validate

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("skyflip")

ROOT = Path(__file__).resolve().parents[2]
SCOREBOARD_PATH = ROOT / "frontend" / "public" / "demo-data" / "scoreboard.json"
VOTES_DB = cache_root() / "votes.sqlite3"

app = FastAPI(
    title="SkyFlip API",
    version="0.2.0",
    description="Blink comparator for NASA SPHEREx. Candidates only — we do not claim Planet X discoveries.",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

adapter = spherex.SpherexAdapter()

TEST_TARGETS = {
    "wise0855": {
        "id": "wise0855",
        "name": "WISE 0855",
        "ra": 133.79512917,
        "dec": -7.24514722,
        "resolve": False,
    },
    "barnards_star": {"id": "barnards_star", "name": "Barnard's Star", "resolve": True},
    "epsilon_indi_b": {"id": "epsilon_indi_b", "name": "Epsilon Indi B", "resolve": True},
    "rw_aurigae": {"id": "rw_aurigae", "name": "RW Aurigae", "resolve": True},
    "r_draconis": {"id": "r_draconis", "name": "R Draconis", "resolve": True},
}


def _array_to_png_bytes(data: np.ndarray, mode: str = "asinh") -> bytes:
    scaled = stretch(data, mode=mode)
    img8 = (scaled * 255).astype(np.uint8)
    im = Image.fromarray(img8, mode="L")
    buf = io.BytesIO()
    im.save(buf, format="PNG")
    return buf.getvalue()


def _demo_manifest(target_id: str) -> Optional[dict[str, Any]]:
    path = DEMO_DATA / target_id / "manifest.json"
    if path.exists():
        return read_json(path)
    return None


def _wcs_dict(wcs) -> dict[str, Any]:
    try:
        return dict(wcs.to_header())
    except Exception:
        return {}


@app.get("/api/health", response_model=HealthResponse)
def health() -> HealthResponse:
    irsa = adapter.ping_irsa()
    simbad = catalogs.ping_simbad()
    jpl = catalogs.ping_jpl()
    services = {
        "irsa": HealthServiceStatus(ok=bool(irsa.get("ok")), detail=str(irsa)[:300]),
        "simbad": HealthServiceStatus(ok=bool(simbad.get("ok")), detail=str(simbad)[:300]),
        "jpl": HealthServiceStatus(ok=bool(jpl.get("ok")), detail=str(jpl)[:300]),
    }
    oks = [s.ok for s in services.values()]
    status = "ok" if all(oks) else ("degraded" if any(oks) else "down")
    return HealthResponse(
        status=status,
        source=DataSource.live,
        services=services,
        demo_cache_available=demo_data_available(),
        pixel_scale_arcsec=PIXEL_SCALE_ARCSEC,
    )


@app.get("/api/targets")
def targets() -> dict[str, Any]:
    return {"targets": list(TEST_TARGETS.values()), "source": "live"}


@app.get("/api/resolve", response_model=ResolveResponse)
def resolve(name: str = Query(..., min_length=1)) -> ResolveResponse:
    try:
        data = catalogs.resolve_name(name)
    except catalogs.CatalogAdapterError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Resolve error: {exc}") from exc
    return ResolveResponse(**data)


@app.get("/api/epochs", response_model=EpochsResponse)
def epochs(
    ra: float = Query(...),
    dec: float = Query(...),
    fov: float = Query(0.05, gt=0, le=2.0),
    bandpass: Optional[str] = None,
    target: Optional[str] = None,
) -> EpochsResponse:
    bands = (bandpass,) if bandpass else ("SPHEREx-D1",)
    try:
        obs = adapter.find_observations(ra, dec, fov_deg=fov, bandpasses=bands)
        source = DataSource.live
    except Exception as exc:
        logger.warning("live epochs failed: %s", exc)
        obs = []
        source = DataSource.cached_demo

    if not obs and target:
        man = _demo_manifest(target)
        if man:
            epochs_out = [
                EpochInfo(
                    epoch_id=f["epoch_id"],
                    obs_id=f.get("obs_id", f["epoch_id"]),
                    mjd=f["mjd"],
                    time_iso=f.get("time_iso", ""),
                    bandpass=f.get("bandpass", "SPHEREx-D1"),
                    detector=f.get("detector", 1),
                    collection=f.get("collection", ""),
                    central_wavelength_um=f.get("central_wavelength_um"),
                    flag_summary=f.get("flag_summary", {}),
                )
                for f in man.get("frames", [])
            ]
            return EpochsResponse(
                ra=ra, dec=dec, fov_deg=fov, epochs=epochs_out, source=DataSource.cached_demo
            )

    epochs_out = [
        EpochInfo(
            epoch_id=f"{o.obs_id}|{o.bandpass}|{o.mjd}",
            obs_id=o.obs_id,
            mjd=o.mjd,
            time_iso=o.time_iso,
            bandpass=o.bandpass,
            detector=o.detector,
            collection=o.collection,
            cutout_url=o.cutout_url,
            s_pixel_scale_arcsec=o.s_pixel_scale_arcsec,
        )
        for o in obs
    ]
    return EpochsResponse(ra=ra, dec=dec, fov_deg=fov, epochs=epochs_out, source=source)


def _select_blink_epochs(obs_list: list, max_frames: int = 8) -> list:
    """Pick well-spaced epochs for blinking (prefer distinct nights)."""
    if not obs_list:
        return []
    obs_list = sorted(obs_list, key=lambda o: o.mjd)
    # Group by integer MJD
    by_day: dict[int, Any] = {}
    for o in obs_list:
        day = int(o.mjd)
        by_day.setdefault(day, o)
    days = sorted(by_day)
    if len(days) <= max_frames:
        return [by_day[d] for d in days]
    idxs = np.linspace(0, len(days) - 1, max_frames).astype(int)
    return [by_day[days[i]] for i in idxs]


@app.get("/api/cutouts", response_model=CutoutsResponse)
def cutouts(
    ra: float,
    dec: float,
    fov: float = Query(0.05, gt=0, le=1.0),
    stack: Literal["none", "detector", "date"] = "none",
    bandpass: str = "SPHEREx-D1",
    stretch_mode: str = "asinh",
    max_frames: int = Query(6, ge=2, le=12),
    target: Optional[str] = None,
) -> CutoutsResponse:
    frames_meta: list[CutoutFrameMeta] = []
    source = DataSource.live
    try:
        obs = adapter.find_observations(ra, dec, fov_deg=fov, bandpasses=(bandpass,))
        chosen = _select_blink_epochs(obs, max_frames=max_frames)
        cut_objs = []
        for o in chosen:
            cut = adapter.fetch_cutout(o)
            cut = adapter.parse_cutout_fits(cut.fits_path, o, target_ra=ra, target_dec=dec)
            cut_objs.append(cut)

        if stack == "detector" and cut_objs:
            # Already single detector; stack all visits for S/N
            aligned = align_frames(
                [Frame(c.image, c.wcs, c.variance, c.flags, c.observation.mjd) for c in cut_objs]
            )
            stacked = stack_mean(aligned)
            png_name = _store_png(stacked, f"stack_{ra:.5f}_{dec:.5f}", stretch_mode)
            frames_meta.append(
                CutoutFrameMeta(
                    epoch_id="stack",
                    obs_id="stack",
                    mjd=float(np.mean([c.observation.mjd for c in cut_objs])),
                    time_iso="stacked",
                    bandpass=bandpass,
                    detector=cut_objs[0].observation.detector,
                    image_url=f"/api/png/{png_name}",
                    central_wavelength_um=cut_objs[0].central_wavelength_um,
                    flag_summary={},
                    wcs=_wcs_dict(cut_objs[0].wcs),
                )
            )
        else:
            # Align to first frame for display consistency
            if cut_objs:
                ref = Frame(cut_objs[0].image, cut_objs[0].wcs)
                aligned = align_frames(
                    [Frame(c.image, c.wcs, mjd=c.observation.mjd) for c in cut_objs], ref
                )
            else:
                aligned = []
            for c, img in zip(cut_objs, aligned):
                eid = f"{c.observation.obs_id}|{c.observation.bandpass}|{c.observation.mjd}"
                png_name = _store_png(img, eid.replace("|", "_"), stretch_mode)
                frames_meta.append(
                    CutoutFrameMeta(
                        epoch_id=eid,
                        obs_id=c.observation.obs_id,
                        mjd=c.observation.mjd,
                        time_iso=c.observation.time_iso,
                        bandpass=c.observation.bandpass,
                        detector=c.observation.detector,
                        image_url=f"/api/png/{png_name}",
                        central_wavelength_um=c.central_wavelength_um,
                        flag_summary=c.flag_summary,
                        wcs=_wcs_dict(c.wcs),
                        bunit=str(c.header_meta.get("BUNIT") or "MJy/sr"),
                    )
                )
    except Exception as exc:
        logger.warning("live cutouts failed: %s", exc)
        source = DataSource.cached_demo
        frames_meta = []

    if not frames_meta and target:
        man = _demo_manifest(target)
        if man:
            source = DataSource.cached_demo
            for f in man.get("frames", []):
                frames_meta.append(
                    CutoutFrameMeta(
                        epoch_id=f["epoch_id"],
                        obs_id=f.get("obs_id", ""),
                        mjd=f["mjd"],
                        time_iso=f.get("time_iso", ""),
                        bandpass=f.get("bandpass", bandpass),
                        detector=f.get("detector", 1),
                        image_url=f"/demo-data/{target}/{f['png']}",
                        central_wavelength_um=f.get("central_wavelength_um"),
                        flag_summary=f.get("flag_summary", {}),
                        wcs=f.get("wcs", {}),
                    )
                )

    if not frames_meta:
        raise HTTPException(
            status_code=503,
            detail="No live cutouts and no cached demo data for this field.",
        )

    return CutoutsResponse(
        ra=ra,
        dec=dec,
        fov_deg=fov,
        stack=stack,
        frames=frames_meta,
        source=source,
        pixel_scale_arcsec=PIXEL_SCALE_ARCSEC,
    )


def _store_png(data: np.ndarray, key: str, mode: str) -> str:
    safe = "".join(ch if ch.isalnum() or ch in "-_." else "_" for ch in key)[:80]
    name = f"{safe}_{mode}.png"
    path = cache_root() / "png" / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(_array_to_png_bytes(data, mode=mode))
    return name


@app.get("/api/png/{name}")
def get_png(name: str):
    path = cache_root() / "png" / name
    if not path.exists():
        raise HTTPException(404, "PNG not found")
    return FileResponse(path, media_type="image/png")


@app.get("/api/diff", response_model=DiffResponse)
def diff_images(
    ra: float,
    dec: float,
    fov: float = 0.05,
    a: str = Query(..., description="epoch_id A"),
    b: str = Query(..., description="epoch_id B"),
    bandpass: str = "SPHEREx-D1",
) -> DiffResponse:
    obs = adapter.find_observations(ra, dec, fov_deg=fov, bandpasses=(bandpass,))
    by_id = {f"{o.obs_id}|{o.bandpass}|{o.mjd}": o for o in obs}
    if a not in by_id or b not in by_id:
        # try match by obs_id substring
        def find(eid):
            if eid in by_id:
                return by_id[eid]
            for k, v in by_id.items():
                if eid in k:
                    return v
            return None

        oa, ob = find(a), find(b)
        if not oa or not ob:
            raise HTTPException(404, "epoch not found")
    else:
        oa, ob = by_id[a], by_id[b]

    ca = adapter.parse_cutout_fits(adapter.fetch_cutout(oa).fits_path, oa, target_ra=ra, target_dec=dec)
    cb = adapter.parse_cutout_fits(adapter.fetch_cutout(ob).fits_path, ob, target_ra=ra, target_dec=dec)
    aligned = align_frames([Frame(ca.image, ca.wcs), Frame(cb.image, cb.wcs)])
    diff = difference(aligned[0], aligned[1])
    name = _store_png(diff, f"diff_{a}_{b}", "asinh")
    return DiffResponse(
        ra=ra,
        dec=dec,
        fov_deg=fov,
        epoch_a=a,
        epoch_b=b,
        image_url=f"/api/png/{name}",
        source=DataSource.live,
    )


@app.get("/api/predicted-track", response_model=PredictedTrackResponse)
def predicted_track(
    ra: float,
    dec: float,
    name: str = Query(...),
    bandpass: str = "SPHEREx-D1",
    fov: float = 0.05,
) -> PredictedTrackResponse:
    """Ghost marker from catalog proper motion (Sesame + SIMBAD pm if available)."""
    try:
        from astroquery.simbad import Simbad

        s = Simbad()
        s.add_votable_fields("pmra", "pmdec")
        tab = s.query_object(name)
    except Exception:
        tab = None

    pmra = pmdec = 0.0
    pm_note = "no proper motion available from resolver; ghost stays fixed"
    if tab is not None and len(tab) > 0:
        row = tab[0]
        for pra, pde in (("pmra", "pmdec"), ("PMRA", "PMDEC")):
            if pra in row.colnames and pde in row.colnames and row[pra] is not np.ma.masked:
                try:
                    pmra = float(row[pra])
                    pmdec = float(row[pde])
                    pm_note = "SIMBAD proper motion (mas/yr → arcsec/yr)"
                    pmra /= 1000.0
                    pmdec /= 1000.0
                except Exception:
                    pass

    # For WISE 0855 use published approximate PM if SIMBAD fails
    # TODO(VERIFY): replace with SIMBAD/Gaia values when available — using literature-scale placeholder flagged
    if "0855" in name or "WISE" in name.upper():
        if pmra == 0 and pmdec == 0:
            # Literature order-of-magnitude for WISE 0855 (~8"/yr); marked as approximate
            pmra, pmdec = -8.1, -0.7  # arcsec/yr approximate; verify against catalog
            pm_note = (
                "Approximate literature-scale proper motion for WISE 0855 "
                "(~8\"/yr); verify against Gaia/AllWISE — uncertainty not formalized"
            )

    epochs = adapter.find_observations(ra, dec, fov_deg=fov, bandpasses=(bandpass,))
    chosen = _select_blink_epochs(epochs, max_frames=8)
    if not chosen:
        # still return single point
        return PredictedTrackResponse(
            name=name,
            ra=ra,
            dec=dec,
            points=[
                PredictedTrackPoint(
                    epoch_id="ref",
                    mjd=0,
                    ra=ra,
                    dec=dec,
                    note=pm_note,
                )
            ],
            method=pm_note,
            pixel_scale_arcsec=PIXEL_SCALE_ARCSEC,
        )

    t0 = chosen[0].mjd
    # Reference position assumed at first epoch coordinates given by user
    points = []
    for o in chosen:
        dt = (o.mjd - t0) / 365.25
        pra = ra + (pmra * dt) / 3600.0 / max(np.cos(np.deg2rad(dec)), 0.2)
        pdec = dec + (pmdec * dt) / 3600.0
        shift_arcsec = np.hypot(pmra * dt, pmdec * dt)
        shift_pix = shift_arcsec / PIXEL_SCALE_ARCSEC
        points.append(
            PredictedTrackPoint(
                epoch_id=f"{o.obs_id}|{o.bandpass}|{o.mjd}",
                mjd=o.mjd,
                ra=float(pra),
                dec=float(pdec),
                note=f"predicted shift {shift_arcsec:.2f}\" ≈ {shift_pix:.2f} SPHEREx pixels; {pm_note}",
            )
        )
    return PredictedTrackResponse(
        name=name,
        ra=ra,
        dec=dec,
        points=points,
        method=pm_note,
        pixel_scale_arcsec=PIXEL_SCALE_ARCSEC,
    )


@app.get("/api/movers", response_model=MoversResponse)
def movers(
    ra: float,
    dec: float,
    fov: float = 0.05,
    bandpass: str = "SPHEREx-D1",
) -> MoversResponse:
    obs = adapter.find_observations(ra, dec, fov_deg=fov, bandpasses=(bandpass,))
    chosen = _select_blink_epochs(obs, max_frames=6)
    per_epoch = []
    for o in chosen:
        cut = adapter.parse_cutout_fits(
            adapter.fetch_cutout(o).fits_path, o, target_ra=ra, target_dec=dec
        )
        eid = f"{o.obs_id}|{o.bandpass}|{o.mjd}"
        dets = detect_sources(cut.image, cut.wcs, eid, o.mjd)
        per_epoch.append(dets)
    tracks = link_detections(per_epoch)
    out = []
    for tr in tracks:
        cls = classify_track(tr)
        out.append(
            MoverCandidate(
                id=tr.id,
                classification=Classification(cls["classification"]),
                reasons=cls["reasons"],
                track=[
                    MoverTrackPoint(
                        epoch_id=d.epoch_id,
                        mjd=d.mjd,
                        ra=d.ra,
                        dec=d.dec,
                        ra_err_arcsec=d.x_err * PIXEL_SCALE_ARCSEC,
                        dec_err_arcsec=d.y_err * PIXEL_SCALE_ARCSEC,
                    )
                    for d in tr.detections
                ],
                pm_ra_arcsec_yr=tr.pm_ra_arcsec_yr,
                pm_dec_arcsec_yr=tr.pm_dec_arcsec_yr,
                pm_ra_err_arcsec_yr=tr.pm_ra_err,
                pm_dec_err_arcsec_yr=tr.pm_dec_err,
                crossmatch=cls.get("crossmatch", {}),
                is_synthetic=tr.is_synthetic,
            )
        )
    return MoversResponse(ra=ra, dec=dec, fov_deg=fov, movers=out, source=DataSource.live)


@app.get("/api/spectrum", response_model=SpectrumResponse)
def spectrum(ra: float, dec: float, fov: float = 0.03) -> SpectrumResponse:
    try:
        data = spectra.extract_spectrum_at(adapter, ra, dec, fov_deg=fov)
    except Exception as exc:
        raise HTTPException(502, f"spectrum failed: {exc}") from exc
    return SpectrumResponse(
        ra=ra,
        dec=dec,
        points=[SpectrumPoint(**p) for p in data["points"]],
        source=DataSource.live,
        unit=data["unit"],
        method_note=data["method_note"] + " Notes: " + "; ".join(data.get("notes", [])),
        is_synthetic=False,
    )


@app.get("/api/scoreboard", response_model=ScoreboardResponse)
def scoreboard() -> ScoreboardResponse:
    self_test = validate.fit_motion_self_test()
    payload: dict[str, Any] = {
        "motion_fit_self_test": self_test,
        "pixel_scale_arcsec": PIXEL_SCALE_ARCSEC,
    }
    source = DataSource.live
    if SCOREBOARD_PATH.exists():
        file_data = read_json(SCOREBOARD_PATH)
        payload.update(file_data)
        source = DataSource(file_data.get("source", "cached-demo"))
    return ScoreboardResponse(
        source=source,
        results=payload,
        is_synthetic_injected=bool(payload.get("synthetic", {}).get("is_synthetic")),
        explanation=(
            "Recovery counts compare detections to known movers within 2 SPHEREx pixels. "
            "Misses are shown deliberately. Synthetic injections are labeled is_synthetic. "
            "This does not claim discovery of Planet X."
        ),
    )


# --- Discovery Mode votes (SQLite optional) ---
def _votes_conn():
    VOTES_DB.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(VOTES_DB)
    conn.execute(
        """CREATE TABLE IF NOT EXISTS votes (
        candidate_id TEXT, vote TEXT, ts REAL
        )"""
    )
    conn.commit()
    return conn


@app.post("/api/votes")
def post_vote(candidate_id: str, vote: Literal["moved", "didnt", "unsure"]):
    conn = _votes_conn()
    import time

    conn.execute(
        "INSERT INTO votes(candidate_id, vote, ts) VALUES (?,?,?)",
        (candidate_id, vote, time.time()),
    )
    conn.commit()
    conn.close()
    return {"ok": True, "source": "live"}


@app.get("/api/votes/{candidate_id}")
def get_votes(candidate_id: str):
    conn = _votes_conn()
    rows = conn.execute(
        "SELECT vote, COUNT(*) FROM votes WHERE candidate_id=? GROUP BY vote",
        (candidate_id,),
    ).fetchall()
    conn.close()
    counts = {k: v for k, v in rows}
    total = sum(counts.values())
    moved = counts.get("moved", 0)
    return {
        "candidate_id": candidate_id,
        "counts": counts,
        "n_votes": total,
        "agreement_pct_moved": (100.0 * moved / total) if total else None,
        "note": "Agreement percentage among volunteers — not a discovery claim.",
        "source": "live",
    }
