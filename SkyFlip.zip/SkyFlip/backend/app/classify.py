"""Triage tracks as known / candidate / likely_artifact."""

from __future__ import annotations

from typing import Any

from .detect import Track


def classify_track(
    track: Track,
    *,
    crossmatch: dict[str, Any] | None = None,
    near_edge: bool = False,
    flagged_fraction: float = 0.0,
) -> dict[str, Any]:
    reasons: list[str] = []
    crossmatch = crossmatch or {}

    if len(track.detections) < 2:
        reasons.append("single-epoch detection")
        return {"classification": "likely_artifact", "reasons": reasons, "crossmatch": crossmatch}

    if near_edge:
        reasons.append("near detector / cutout edge")
    if flagged_fraction > 0.3:
        reasons.append("high fraction of flagged pixels near source")

    # Known if cross-matched within ~2 SPHEREx pixels (~12")
    if crossmatch.get("name"):
        reasons.append(f"cross-matched to {crossmatch['name']} ({crossmatch.get('catalog', 'catalog')})")
        return {"classification": "known", "reasons": reasons, "crossmatch": crossmatch}

    pm = abs(track.pm_ra_arcsec_yr or 0) + abs(track.pm_dec_arcsec_yr or 0)
    if pm < 0.5:
        reasons.append("negligible fitted motion (<0.5\"/yr) — may be stationary / variable")
    else:
        reasons.append("significant fitted motion without catalog match — candidate")

    if near_edge or flagged_fraction > 0.3:
        return {"classification": "likely_artifact", "reasons": reasons, "crossmatch": crossmatch}

    if pm < 0.5:
        return {"classification": "likely_artifact", "reasons": reasons, "crossmatch": crossmatch}

    return {"classification": "candidate", "reasons": reasons, "crossmatch": crossmatch}
