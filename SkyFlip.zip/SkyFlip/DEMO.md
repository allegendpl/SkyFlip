# Demo script (60–90 s)

## Pre-flight

- [ ] `make precache` completed (five targets under `frontend/public/demo-data/`)
- [ ] `make backend` and `make frontend` running
- [ ] Browser tab open to http://127.0.0.1:5173 (or `/?demo=1` for auto-walk)
- [ ] Audio unmuted (sonification)
- [ ] Optional: DevTools → Network Offline to prove cached-demo banner

## Script

1. **Hook** — A billion SPHEREx objects. No one can look at them all. SkyFlip is a blink comparator with proof.
2. **See it** — Click **WISE 0855**. Play blink. Dot hops. Toggle **Ghost track** — marker tracks expected motion (coarse pixels: ~1–2 pix shifts possible).
3. **Prove it** — Open **Scoreboard**. Show recovered vs missed + **Limits** panel.
4. **Hear it** — **Load spectrum** → **Play sonification**. Caption describes mapping (not a real sky sound).
5. **Look ahead** — **Discovery Mode** votes; **Planet X meter** (motion easy, brightness hard). Close with what we cannot detect yet.

## Manual QA

- [ ] All five targets live and cached
- [ ] `?embed=1` minimal chrome
- [ ] Mobile width
- [ ] Keyboard-only (Tab, Space, arrows, Discovery 1/2/3)
- [ ] `prefers-reduced-motion` starts paused
